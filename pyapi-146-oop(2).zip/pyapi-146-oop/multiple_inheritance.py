# Множественное наследование

class Person:
    def __init__(self, name):
        self.name = name
    def introduce(self):
        return f"Меня зовут {self.name}."
    def act(self):
        return "Я помогаю людям."

class Spider:
    def __init__(self, species):
        self.species = species
    def act(self):
        return "Я плету паутину и ловлю мух."

class SpiderMan(Person, Spider):  # Наследуемся от двух классов
    def __init__(self, name):
        # Вызываем конструктор только первого родителя (Person)
        super().__init__(name)


print("Множественное наследование")
peter = SpiderMan("Питер Паркер")
print(peter.introduce())
print(peter.act())

# Порядок разрешения методов (MRO) определяет, какой родительский метод будет вызван.
print("\nПорядок разрешения методов (MRO) для SpiderMan:")
print(SpiderMan.__mro__)  # Показывает цепочку наследования для поиска методов