# Пример плохого кода без инкапсуляции

class Account:
    def __init__(self, owner: str, balance: int):
        self.owner = owner
        self.balance = balance

    def show(self):
        print(f"Владелец: {self.owner}, Баланс: {self.balance}")

# Создаем счет
print("Пример 1: Прямой доступ")
account1 = Account("Александр", 1000)
account1.show()

# Проблема №1: Можем просто прочитать приватные данные
print(f"Просто читаем баланс: {account1.balance}")
print(f"Просто читаем владельца: {account1.owner}")

# Проблема №2: Можем ИЗМЕНИТЬ их как угодно, даже на некорректные значения!
print("\n=== Пример 2: Прямое изменение (опасно!) ===")
account1.owner = "Олег"  # Меняем владельца просто так
account1.balance = "миллиард"  # Меняем баланс на строку (абсурд!)
# account1.balance = -2000  # Или на отрицательное число
account1.show()  # Результат катастрофичен