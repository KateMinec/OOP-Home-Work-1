# Проблема дублирования кода

class DebitAccount:
    """Дебетовый счет (нельзя уходить в минус)."""
    def __init__(self, owner, balance):
        self.owner = owner
        self.balance = balance
    def deposit(self, amount):
        if isinstance(amount, int) and amount > 0:
            self.balance += amount
    def withdraw(self, amount):
        # Отличие от обычного счета: проверка, чтобы не уйти в минус
        if isinstance(amount, int) and amount > 0 and amount <= self.balance:
            self.balance -= amount
        else:
            print("Недостаточно средств или неверная сумма.")
    def show(self):
        print(f"Дебетовый счет. Владелец: {self.owner}, Баланс: {self.balance}")

print("=== Дублирование кода ведет к ошибкам и сложностям в поддержке ===")