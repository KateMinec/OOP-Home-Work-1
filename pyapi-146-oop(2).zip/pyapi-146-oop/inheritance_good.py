# Правильная иерархия классов

class Account:
    """Базовый класс для всех счетов."""
    def __init__(self, owner: str, balance: int = 0):
        # Делаем атрибуты защищенными, чтобы дочерние классы могли к ним обращаться
        self._owner = owner
        self._balance = balance

    def deposit(self, amount: int):
        if isinstance(amount, int) and amount > 0:
            self._balance += amount
            print(f"Пополнение на {amount}. Баланс: {self._balance}")
        else:
            raise ValueError("Сумма должна быть положительным целым числом.")

    def show(self):
        print(f"Счет. Владелец: {self._owner}, Баланс: {self._balance}")

class DebitAccount(Account):  # Наследуемся от Account
    """Дебетовый счет. Не может уходить в минус."""
    # __init__ не переопределен, поэтому используется родительский

    def deposit(self, amount: int):
        if isinstance(amount, int) and amount > 0:
            self._balance += amount
            print(f"Пополнение на {amount}. Баланс: {self._balance}")
        else:
            raise ValueError("Сумма должна быть положительным целым числом.")

    def withdraw(self, amount: int):
        # Переопределяем метод: добавляем проверку на достаточность средств
        if isinstance(amount, int) and amount > 0:
            if amount <= self._balance:  # Используем защищенный атрибут
                self._balance -= amount
                print(f"Снято {amount}. Баланс: {self._balance}")
            else:
                print("Ошибка: Недостаточно средств на счете.")
        else:
            raise ValueError("Сумма должна быть положительным целым числом.")


# Тестируем
print("Базовый и дебетовый счет")
base_acc = Account("Базовый клиент", 1000)
base_acc.deposit(500)
# base_acc.withdraw(200)
base_acc.show()

print("\n---")
debit_acc = DebitAccount("Владимир", 2000)
debit_acc.show()      # Унаследованный метод
debit_acc.deposit(300) # Унаследованный метод
debit_acc.withdraw(500) # Свой, переопределенный метод
debit_acc.withdraw(2500) # Сработает проверка на недостаточность средств