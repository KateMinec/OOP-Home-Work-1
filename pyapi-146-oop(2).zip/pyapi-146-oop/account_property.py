# Используем @property

class Account:
    def __init__(self, owner: str, balance: int):
        self._owner = owner
        self.__balance = balance

    # Геттер для баланса - позволяет читать как атрибут: acc.balance
    @property
    def balance(self):
        """Возвращает текущий баланс."""
        return self.__balance

    # Сеттер для баланса - позволяет писать acc.balance = value
    @balance.setter
    def balance(self, value):
        """Устанавливает баланс с проверкой."""
        if isinstance(value, int) and value >= 0:
            self.__balance = value
        else:
            raise ValueError("Баланс должен быть неотрицательным целым числом.")

    # Пример свойства только для чтения (геттер без сеттера)
    @property
    def owner(self):
        return self._owner

    # Можно создавать вычисляемые свойства
    @property
    def is_millionaire(self):
        return self.__balance >= 1_000_000


print("=== Работа со свойствами ===")
acc = Account("Мария", 750)
print(f"Читаем баланс как свойство: {acc.balance}")
print(f"Владелец (только чтение): {acc.owner}")
print(f"Является ли миллионером? {acc.is_millionaire}")


# Пытаемся установить баланс
try:
    acc.balance = 950  # Корректное значение
    print(f"Новый баланс: {acc.balance}")
    acc.balance = -100 # Некорректное значение
except ValueError as e:
    print(f"Ошибка: {e}")

# acc.owner = "Иван"  # ОШИБКА! У свойства owner нет сеттера.

