# Защищаем данные

class Account:
    def __init__(self, owner: str, balance: int):
        self._owner = owner
        self.__balance = balance

    def show(self):
        print(f"Владелец: {self._owner}, Баланс: {self.__balance}")

    # Метод для пополнения счета
    def deposit(self, amount: int):
        if isinstance(amount, int) and amount > 0:
            self.__balance += amount
            print(f"Счет пополнен на {amount}. Новый баланс: {self.__balance}")
        else:
            # Вызываем ошибку, если данные некорректны
            raise ValueError("Сумма пополнения должна быть положительным целым числом.")

    # Метод для снятия средств
    def withdraw(self, amount: int):
        if isinstance(amount, int) and amount > 0:
            if amount <= self.__balance:
                self.__balance -= amount
                print(f"Со счета снято {amount}. Новый баланс: {self.__balance}")
            else:
                print("Недостаточно средств на счете.")
        else:
            raise ValueError("Сумма снятия должна быть положительным целым числом.")


# print("Пример с Protected и Private")
# acc = Account("Анна", 500)

# К protected-атрибуту (_owner) все еще можно получить доступ (но не нужно)
# print(f"Доступ к защищенному атрибуту _owner: {acc._owner}")  # Работает, но редактор ругается

# К private-атрибуту (__balance) напрямую уже не получится
# print(acc.__balance)  # ОШИБКА! AttributeError: 'Account' object has no attribute '__balance'

# Но Python сохраняет его под другим именем (_ИмяКласса__ИмяАтрибута)
# Это нужно знать, но НЕ ИСПОЛЬЗОВАТЬ в реальном коде!
# print(f"Обходной путь (знать, но не использовать!): {acc._Account__balance}")

# Тестируем новые методы
print("\n=== Работа через публичные методы ===")
safe_acc = Account("Петр", 1500)
safe_acc.show()
# safe_acc.deposit(500)   # Работает
# safe_acc.deposit("тысяча")  # Вызовет ValueError
# safe_acc.deposit(-100)      # Вызовет ValueError
# safe_acc.withdraw(200)  # Работает
safe_acc.withdraw(5000) # Отказ: недостаточно средств
safe_acc.show()




