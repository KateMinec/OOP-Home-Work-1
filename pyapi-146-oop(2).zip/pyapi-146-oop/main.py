# Инкапсуляция

# _ - protected
# __ - private

# Наследование

# class Example(TargetClass)
# super()

# Полиморфизм

# "утиная типизация"
# "магические методы"