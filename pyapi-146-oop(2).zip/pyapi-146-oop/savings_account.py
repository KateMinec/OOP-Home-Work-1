# Наследование с расширением

from inheritance_good import DebitAccount

class SavingsAccount(DebitAccount):
    """Накопительный счет с процентной ставкой."""
    def __init__(self, owner: str, balance: int, interest_rate: float):
        # Сначала инициализируем часть родителя (владелец и баланс)
        super().__init__(owner, balance)
        # Затем добавляем собственный атрибут
        self._interest_rate = interest_rate

    # Добавляем новый метод, специфичный для этого класса
    def apply_interest(self):
        """Начисляет проценты на остаток."""
        interest = int(self._balance * self._interest_rate / 100)
        self._balance += interest
        print(f"Начислены проценты: {interest}. Новый баланс: {self._balance}")

    # Переопределяем метод show, чтобы выводить больше информации
    def show(self):
        print(f"Накопительный счет. Владелец: {self._owner}, "
              f"Баланс: {self._balance}, Ставка: {self._interest_rate}%")

print("Накопительный счет")
savings = SavingsAccount("Алексей", 1000, 10)
savings.show()  # Используется переопределенный метод
savings.deposit(500)   # Унаследованный от DebitAccount
savings.withdraw(200)  # Унаследованный от DebitAccount
savings.apply_interest() # Собственный метод
savings.show()