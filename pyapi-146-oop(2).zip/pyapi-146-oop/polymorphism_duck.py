# Утиная типология

class Duck:
    def quack(self):
        return "Кря-кря!"

class Person:
    def quack(self):
        return "Я притворяюсь уткой: Кря!"

class Car:
    def honk(self):
        return "Би-бип!"

def make_it_quack(thing):
    # Функция не проверяет тип, только наличие метода .quack()
    try:
        print(thing.quack())
    except AttributeError:
        print(f"{thing} не может крякать!")

print("Утиная типизация")
duck = Duck()
person = Person()
car = Car()

make_it_quack(duck)
make_it_quack(person)
make_it_quack(car)  # У автомобиля нет метода .quack()


