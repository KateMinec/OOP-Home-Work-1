# Магические методы
"""
a + b -> a.__add__(b)
"""

class Bill:
    """Класс для представления денежного счета (доллары и центы)."""
    def __init__(self, dollars: int, cents: int):
        self.dollars = dollars
        self.cents = cents
        self._normalize()  # Приводим к нормальному виду (например, 1$ 150c -> 2$ 50c)

    def _normalize(self):
        """Приводит доллары и центы к нормальной форме."""
        total_cents = self.dollars * 100 + self.cents
        self.dollars = total_cents // 100
        self.cents = total_cents % 100

    # Магический метод для строкового представления (вызов print(), str())
    def __str__(self):
        return f"${self.dollars}.{self.cents:02d}"

    # Магический метод для сравнения на равенство (==)
    def __eq__(self, other):
        if isinstance(other, Bill):
            return self.dollars == other.dollars and self.cents == other.cents
        return False

    # Магический метод для сложения (+)
    def __add__(self, other):
        if isinstance(other, Bill):
            new_dollars = self.dollars + other.dollars
            new_cents = self.cents + other.cents
            return Bill(new_dollars, new_cents)  # Возвращаем НОВЫЙ объект
        raise TypeError(f"Нельзя сложить Bill с {type(other)}")

    # Магический метод для умножения на число (*)
    def __mul__(self, multiplier: int):
        if isinstance(multiplier, int):
            new_dollars = self.dollars * multiplier
            new_cents = self.cents * multiplier
            return Bill(new_dollars, new_cents)
        raise TypeError(f"Нельзя умножить Bill на {type(multiplier)}")

    # Отраженный метод умножения (число * Bill). Вызывается, если первый операнд не поддерживает *
    def __rmul__(self, multiplier: int):
        return self.__mul__(multiplier)  # Умножение коммутативно



print("Магические методы для полиморфизма")
bill1 = Bill(10, 20)
bill2 = Bill(5, 90)
bill3 = Bill(10, 20)

print(f"\nbill1 == bill2? {bill1 == bill2}") # Используется __eq__
print(f"bill1 == bill3? {bill1 == bill3}")

total = bill1 + bill2  # Используется __add__
print(f"\nbill1 + bill2 = {total}")

double_bill = bill1 * 2  # Используется __mul__
print(f"bill1 * 2 = {double_bill}")

triple_bill = 3 * bill1  # Используется __rmul__
print(f"3 * bill1 = {triple_bill}")

# print(bill1 + 100)  # Вызовет TypeError из __add__






